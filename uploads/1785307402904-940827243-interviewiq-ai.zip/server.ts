import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(express.json());

const PORT = 3000;

// Initialize Gemini Client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build",
    },
  },
});

// Simple In-Memory Database Simulation
let users = [{ id: 1, email: "admin@interviewiq.com", role: "admin", name: "Admin User" }, { id: 2, email: "candidate@mail.com", role: "candidate", name: "John Doe" }];
let interviews = [];

// ---- API Routes ----

// 1. Mock Login
app.post("/api/auth/login", (req, res) => {
  const { email, password } = req.body;
  const user = users.find((u) => u.email === email) || users[1]; // default to candidate
  res.json({ token: "mock-jwt-token-" + user.id, user });
});

// 2. Generate Interview Questions
app.post("/api/interview/questions", async (req, res) => {
  const { role = "Software Engineer", seniority = "Junior" } = req.body;
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: `Generate 3 technical and 2 behavioral interview questions for a ${seniority} ${role} role. Return ONLY a valid JSON array of strings. No markdown formatting blocks like \`\`\`json`,
    });
    
    let text = response.text || "[]";
    text = text.replace(/```json/g, "").replace(/```/g, "").trim();
    
    let questions;
    try {
      questions = JSON.parse(text);
    } catch(e) {
      questions = ["Can you describe your experience?", "How do you handle conflict?", "What is your biggest weakness?", "Explain a complex technical concept.", "Why do you want this role?"];
    }
    
    res.json({ questions });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to generate questions" });
  }
});

// 3. Evaluate Interview Answer (Simulated Multimodal / NLP fallback)
app.post("/api/interview/evaluate", async (req, res) => {
  const { question, transcript, duration } = req.body;
  
  // Fake Voice & Facial Analysis Data for the MVP
  const simulatedEmotionText = "neutral, confident";
  const confidenceScore = Math.floor(Math.random() * 20) + 80; // 80-100
  const eyeContactScore = Math.floor(Math.random() * 15) + 85; // 85-100

  try {
    const prompt = `
A candidate was asked: "${question}"
Their transcribed answer was: "${transcript}"
Duration: ${duration} seconds.
Apparent emotions detected visually/vocally (simulated): ${simulatedEmotionText}.

Evaluate this answer. 
Provide:
1. "score": out of 100 for the answer's quality, relevance, and articulation.
2. "feedback": 2-3 sentences of constructive feedback.
3. "strengths": Array of 1-3 strengths.
4. "weaknesses": Array of 1-3 weaknesses.

Return EXACTLY a JSON object with keys: score (number), feedback (string), strengths (array of strings), weaknesses (array of strings). No markdown formatting blocks like \`\`\`json.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
    });

    let text = response.text || "{}";
    text = text.replace(/```json/g, "").replace(/```/g, "").trim();
    
    let analysis;
    try {
      analysis = JSON.parse(text);
    } catch(e) {
      analysis = {
        score: 75,
        feedback: "The answer was reasonable but lacked depth.",
        strengths: ["Clear communication"],
        weaknesses: ["Needs more specific examples"]
      };
    }

    const fullResult = {
      ...analysis,
      confidenceScore,
      eyeContactScore,
      transcript
    };

    res.json(fullResult);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Failed to evaluate answer" });
  }
});

// 4. Submit Final Interview (Save to mock DB)
app.post("/api/interview/submit", (req, res) => {
  const { candidateName, role, overallScore, details } = req.body;
  const newInterview = {
    id: Date.now(),
    candidateName,
    role,
    date: new Date().toISOString().split("T")[0],
    status: overallScore > 75 ? "Passed" : "Under Review",
    score: overallScore,
    details
  };
  interviews.push(newInterview);
  res.json({ success: true, interviewId: newInterview.id });
});

// 5. Dashboard Data
app.get("/api/dashboard", (req, res) => {
  // Return mock stats + history
  const history = interviews.length > 0 ? interviews : [
     { id: 101, candidateName: "Alice Smith", role: "Frontend Dev", date: "2026-05-25", status: "Passed", score: 88 },
     { id: 102, candidateName: "Bob Johnson", role: "Backend Dev", date: "2026-05-26", status: "Rejected", score: 65 },
     { id: 103, candidateName: "Charlie Brown", role: "Data Scientist", date: "2026-05-27", status: "Passed", score: 92 },
  ];

  const stats = {
    totalInterviews: history.length + 152,
    avgScore: Math.round(history.reduce((a,b)=>a+b.score, 0) / history.length) || 82,
    hired: 45,
    pending: 12
  };
  
  res.json({ stats, history });
});


// ---- Vite Middleware (for Development and Production) ----
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
