import { Link, useLocation } from "react-router-dom";
import { BrainCircuit } from "lucide-react";

export default function Navbar() {
  const location = useLocation();
  const isDashboard = location.pathname.startsWith("/dashboard");
  const isInterview = location.pathname.startsWith("/interview");

  if (isInterview) return null; // No navbar during active interview

  return (
    <nav className="sticky top-0 z-50 w-full backdrop-blur-md bg-[#020617]/80 border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center gap-2">
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center font-bold text-white text-sm">IQ</div>
            <span className="text-xl font-bold tracking-tight text-white">InterviewIQ <span className="text-indigo-500">AI</span></span>
          </Link>
          
          <div className="flex items-center gap-4">
            {isDashboard ? (
              <Link to="/setup" className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-medium rounded-full transition-colors">
                New Interview
              </Link>
            ) : (
              <>
                <Link to="/login" className="text-sm font-medium text-slate-400 hover:text-slate-200 transition-colors">
                   Sign In
                </Link>
                <Link to="/login" className="px-4 py-1.5 bg-slate-800 text-white text-xs font-medium rounded-full transition-colors hover:bg-slate-700">
                  Get Started
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
