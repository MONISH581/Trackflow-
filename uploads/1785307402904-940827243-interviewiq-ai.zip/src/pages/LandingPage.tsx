import { Link } from "react-router-dom";
import { Brain, Sparkles, Video, BarChart3, ShieldCheck } from "lucide-react";

export default function LandingPage() {
  return (
    <div className="flex flex-col min-h-[calc(100vh-4rem)]">
      <section className="flex-1 flex flex-col items-center justify-center text-center px-4 py-20 relative overflow-hidden">
        {/* Background glow effects */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-indigo-600/20 rounded-full blur-[120px] -z-10" />
        
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-400 text-sm font-medium mb-8 border border-indigo-500/20">
          <Sparkles className="w-4 h-4" />
          <span>The Future of AI Recruitment</span>
        </div>
        
        <h1 className="text-5xl md:text-7xl font-bold tracking-tight max-w-4xl mb-6 text-white">
          Hire Top Talent with <br className="hidden md:block"/>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-violet-400">
            Cognitive AI Analysis
          </span>
        </h1>
        
        <p className="text-lg md:text-xl text-slate-400 max-w-2xl mb-10">
          InterviewIQ evaluates candidates in real-time. Our AI engine analyzes speech, sentiment, and technical knowledge to help you make automated, unbiased hiring decisions.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
          <Link to="/login" className="px-8 py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-full font-medium text-lg transition-colors flex items-center justify-center gap-2">
            Start Free Trial
          </Link>
          <Link to="/login" className="px-8 py-4 bg-slate-800 text-white border border-slate-700 hover:bg-slate-700 rounded-full font-medium text-lg transition-colors flex items-center justify-center">
            View Demo
          </Link>
        </div>
      </section>

      <section className="py-20 bg-[#020617]/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <FeatureCard 
              icon={<Video className="w-6 h-6 text-indigo-500" />}
              title="Real-time Evaluation"
              description="Automated AI monitoring of facial expressions, eye contact, and vocal confidence."
            />
            <FeatureCard 
              icon={<Brain className="w-6 h-6 text-violet-500" />}
              title="NLP Knowledge Assessment"
              description="Dynamic technical and behavioral questions generated and graded by Gemini AI."
            />
            <FeatureCard 
              icon={<BarChart3 className="w-6 h-6 text-emerald-500" />}
              title="Deep Analytics"
              description="Comprehensive candidate performance reports detailing strengths, weaknesses, and a final score."
            />
          </div>
        </div>
      </section>
    </div>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) {
  return (
    <div className="bg-slate-900/50 backdrop-blur-xl border border-slate-800 p-8 rounded-3xl transition-transform hover:-translate-y-1">
      <div className="bg-slate-800/50 w-14 h-14 rounded-2xl flex items-center justify-center mb-6">
        {icon}
      </div>
      <h3 className="text-sm font-bold tracking-widest uppercase mb-3 text-slate-200">{title}</h3>
      <p className="text-slate-400 text-sm leading-relaxed">{description}</p>
    </div>
  );
}
