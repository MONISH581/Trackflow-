import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Video, Settings2, ShieldCheck, Camera, Mic } from "lucide-react";

export default function InterviewSetup() {
  const navigate = useNavigate();
  const [role, setRole] = useState("Software Engineer");
  const [seniority, setSeniority] = useState("Junior");
  const [name, setName] = useState("");
  const [isReady, setIsReady] = useState(false);

  const startInterview = () => {
    // Store context for the interview room
    localStorage.setItem("interview_context", JSON.stringify({ role, seniority, name }));
    navigate("/interview");
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold text-center text-white mb-2">Configure AI Interview</h1>
      <p className="text-center text-slate-400 mb-10">Set up the evaluation parameters for the candidate</p>

      <div className="bg-slate-900/50 backdrop-blur-xl border border-slate-800 rounded-3xl p-8 shadow-[0_0_80px_rgba(79,70,229,0.05)]">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          
          {/* Configuration form */}
          <div className="space-y-6">
            <div className="flex items-center gap-2 mb-4 text-indigo-400 font-medium">
              <Settings2 className="w-5 h-5" />
              <span>Interview Settings</span>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-1">Candidate Name</label>
              <input 
                type="text" 
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-3 bg-[#020617] border border-slate-800 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-white"
                placeholder="John Doe"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-400 mb-1">Target Role</label>
              <select 
                value={role}
                onChange={(e) => setRole(e.target.value)}
                className="w-full px-4 py-3 bg-[#020617] border border-slate-800 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-white"
              >
                <option>Software Engineer</option>
                <option>Data Scientist</option>
                <option>Product Manager</option>
                <option>Sales Executive</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-400 mb-1">Seniority Level</label>
              <select 
                value={seniority}
                onChange={(e) => setSeniority(e.target.value)}
                className="w-full px-4 py-3 bg-[#020617] border border-slate-800 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-white"
              >
                <option>Intern / entry-level</option>
                <option>Junior</option>
                <option>Mid-Level</option>
                <option>Senior</option>
              </select>
            </div>
          </div>

          {/* System Check / Permission */}
          <div className="space-y-6 bg-[#020617]/50 p-6 rounded-2xl border border-slate-800">
            <div className="flex items-center gap-2 mb-4 text-emerald-400 font-medium">
              <ShieldCheck className="w-5 h-5" />
              <span>System Requirements</span>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-slate-900/50 rounded-xl border border-slate-800">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-indigo-500/10 rounded-lg text-indigo-400"><Camera className="w-4 h-4"/></div>
                  <span className="text-sm font-medium text-white">Camera Access</span>
                </div>
                <div className="text-[10px] font-bold text-emerald-500 bg-emerald-500/10 px-2 py-1 rounded uppercase tracking-widest">Required</div>
              </div>

              <div className="flex items-center justify-between p-3 bg-slate-900/50 rounded-xl border border-slate-800">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-indigo-500/10 rounded-lg text-indigo-400"><Mic className="w-4 h-4"/></div>
                  <span className="text-sm font-medium text-white">Microphone Access</span>
                </div>
                <div className="text-[10px] font-bold text-emerald-500 bg-emerald-500/10 px-2 py-1 rounded uppercase tracking-widest">Required</div>
              </div>
              
              <div className="pt-2">
                <label className="flex items-start gap-3 cursor-pointer">
                  <input type="checkbox" checked={isReady} onChange={(e) => setIsReady(e.target.checked)} className="mt-1 w-4 h-4 text-indigo-600 rounded bg-[#020617] border-slate-700" />
                  <span className="text-sm text-slate-400">I confirm that the candidate has consented to AI analysis of video/audio strictly for this evaluation.</span>
                </label>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-10 border-t border-slate-800 pt-8 flex justify-end">
          <button 
            disabled={!isReady || !name.trim()}
            onClick={startInterview}
            className="flex items-center gap-2 px-8 py-3 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-full text-sm font-bold uppercase tracking-widest transition-colors shadow-lg shadow-indigo-500/20"
          >
            <Video className="w-5 h-5"/>
            Initialize AI Interview Engine
          </button>
        </div>
      </div>
    </div>
  );
}
