import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Users, CheckCircle2, XCircle, Clock, Video, Download } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

export default function Dashboard() {
  const [data, setData] = useState({ stats: null, history: [] });

  useEffect(() => {
    fetch("/api/dashboard")
      .then(res => res.json())
      .then(d => setData(d))
      .catch(console.error);
  }, []);

  const { stats, history } = data;

  const chartData = [
    { name: 'Mon', score: 85 },
    { name: 'Tue', score: 72 },
    { name: 'Wed', score: 90 },
    { name: 'Thu', score: 78 },
    { name: 'Fri', score: 88 },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-white">Overview</h1>
          <p className="text-slate-400">Welcome back, Admin</p>
        </div>
        <Link to="/setup" className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-full text-xs font-medium transition-colors">
          <Video className="w-4 h-4" />
          Assign AI Interview
        </Link>
      </div>

      {stats ? (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <StatCard icon={<Users className="w-5 h-5 text-indigo-400"/>} label="Total Interviews" value={stats.totalInterviews} />
          <StatCard icon={<CheckCircle2 className="w-5 h-5 text-emerald-400"/>} label="Average AI Score" value={`${stats.avgScore}%`} />
          <StatCard icon={<Users className="w-5 h-5 text-indigo-400"/>} label="Candidates Hired" value={stats.hired} />
          <StatCard icon={<Clock className="w-5 h-5 text-amber-400"/>} label="Pending Review" value={stats.pending} />
        </div>
      ) : (
        <div className="h-24 bg-slate-900/50 border border-slate-800 animate-pulse rounded-2xl mb-8"></div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-slate-900/50 backdrop-blur-xl border border-slate-800 rounded-2xl p-6">
          <h2 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-6">Recent Candidates</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="text-slate-500 text-xs tracking-wider uppercase border-b border-slate-800">
                  <th className="pb-3 font-bold">Candidate</th>
                  <th className="pb-3 font-bold">Role</th>
                  <th className="pb-3 font-bold">Date</th>
                  <th className="pb-3 font-bold">Score</th>
                  <th className="pb-3 font-bold">Status</th>
                  <th className="pb-3 font-bold">Action</th>
                </tr>
              </thead>
              <tbody className="text-sm">
                {history.map((item: any, i) => (
                  <tr key={i} className="border-b border-slate-800/50 last:border-0 hover:bg-slate-800/30 transition-colors">
                    <td className="py-4 font-medium text-white">{item.candidateName}</td>
                    <td className="py-4 text-slate-400">{item.role}</td>
                    <td className="py-4 text-slate-400">{item.date}</td>
                    <td className="py-4 font-bold text-indigo-400">{item.score}</td>
                    <td className="py-4">
                      <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase tracking-tighter ${
                        item.status === 'Passed' ? 'bg-emerald-500/10 text-emerald-500' :
                        item.status === 'Rejected' ? 'bg-rose-500/10 text-rose-500' :
                        'bg-amber-500/10 text-amber-500'
                      }`}>
                        {item.status}
                      </span>
                    </td>
                    <td className="py-4">
                      <Link to={`/report/${item.id}`} className="text-[11px] font-bold text-indigo-400 hover:text-indigo-300 uppercase tracking-widest">View</Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="bg-slate-900/50 backdrop-blur-xl border border-slate-800 rounded-2xl p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xs font-bold text-slate-500 uppercase tracking-widest">Avg Score Trend</h2>
            <button className="p-2 hover:bg-slate-800 rounded-lg transition-colors text-slate-400">
              <Download className="w-4 h-4" />
            </button>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#334155" opacity={0.2} />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b'}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b'}} />
                <Tooltip 
                  cursor={{fill: 'rgba(99, 102, 241, 0.1)'}}
                  contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }}
                />
                <Bar dataKey="score" fill="#6366f1" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon, label, value }: { icon: React.ReactNode, label: string, value: string | number }) {
  return (
    <div className="bg-slate-900/50 backdrop-blur-xl border border-slate-800 p-6 rounded-2xl flex items-center gap-4">
      <div className="p-3 bg-slate-800/80 rounded-xl">
        {icon}
      </div>
      <div>
        <div className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-1">{label}</div>
        <div className="text-2xl font-light text-white">{value}</div>
      </div>
    </div>
  );
}
