import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { ChevronLeft, Download, Award, Target, Brain, Activity, UserCheck } from "lucide-react";
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer } from "recharts";

export default function Report() {
  const { id } = useParams();
  const [data, setData] = useState<any>(null);
  
  useEffect(() => {
    // In a real app we'd fetch this specific interview ID.
    // For this mock we fetch dashboard data and find it, or fallback.
    fetch("/api/dashboard")
      .then(res => res.json())
      .then(d => {
        const found = d.history.find((h:any) => h.id.toString() === id);
        if (found) {
          setData(found);
        } else {
          // Mock structure for preview if refreshed directly
          setData({
            candidateName: "Unknown Candidate",
            role: "Software Engineer",
            score: 82,
            status: "Passed",
            details: [
              {
                question: "Describe your experience.",
                transcript: "I have 3 years of experience...",
                score: 85,
                confidenceScore: 90,
                eyeContactScore: 88,
                feedback: "Good concise answer.",
                strengths: ["Clarity", "Confidence"],
                weaknesses: []
              }
            ]
          });
        }
      });
  }, [id]);

  if (!data) {
    return <div className="p-20 text-center animate-pulse">Generating comprehensive AI report...</div>;
  }

  // Aggregate stats from details if available
  const avgConfidence = data.details?.length ? Math.round(data.details.reduce((a:any, b:any) => a + b.confidenceScore, 0) / data.details.length) : 85;
  const avgEyeContact = data.details?.length ? Math.round(data.details.reduce((a:any, b:any) => a + b.eyeContactScore, 0) / data.details.length) : 80;

  const radarData = [
    { subject: 'Technical skills', A: data.score, fullMark: 100 },
    { subject: 'Communication', A: avgConfidence, fullMark: 100 },
    { subject: 'Confidence', A: avgConfidence, fullMark: 100 },
    { subject: 'Body Language', A: avgEyeContact, fullMark: 100 },
    { subject: 'Problem Solving', A: Math.min(data.score + 5, 100), fullMark: 100 },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      
      <div className="flex items-center justify-between mb-8">
        <Link to="/dashboard" className="flex items-center gap-2 text-slate-500 hover:text-white transition-colors">
          <ChevronLeft className="w-5 h-5"/> Back to Dashboard
        </Link>
        <button className="flex items-center gap-2 px-4 py-2 bg-indigo-500/10 text-indigo-400 font-medium rounded-full hover:bg-indigo-500/20 transition-colors text-xs">
          <Download className="w-4 h-4"/> Export PDF
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Column: Candidate Overview & Radar */}
        <div className="lg:col-span-1 space-y-8">
          
          <div className="bg-slate-900/50 backdrop-blur-xl border border-slate-800 p-8 rounded-3xl relative overflow-hidden">
            <div className={`absolute top-0 left-0 w-full h-2 ${data.score >= 80 ? 'bg-emerald-500' : 'bg-amber-500'}`} />
            
            <div className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">{data.role}</div>
            <h1 className="text-3xl font-bold text-white mb-6">{data.candidateName}</h1>
            
            <div className="flex items-end gap-3 mb-8">
              <span className="text-6xl font-black tracking-tighter text-indigo-400">{data.score}</span>
              <span className="text-slate-500 font-medium pb-2">/ 100 final score</span>
            </div>

            <div className="space-y-4">
              <div className="flex justify-between items-center py-3 border-t border-slate-800">
                <span className="flex items-center gap-2 text-slate-400"><Activity className="w-4 h-4"/> AI Recommendation</span>
                <span className={`font-bold ${data.status === 'Passed' ? 'text-emerald-500 bg-emerald-500/10 px-2 py-0.5 rounded text-[10px] uppercase tracking-widest' : 'text-amber-500 bg-amber-500/10 px-2 py-0.5 rounded text-[10px] uppercase tracking-widest'}`}>{data.status === 'Passed' ? 'Hire' : 'Review'}</span>
              </div>
              <div className="flex justify-between items-center py-3 border-t border-slate-800">
                <span className="flex items-center gap-2 text-slate-400"><Target className="w-4 h-4"/> Vocal Confidence</span>
                <span className="font-bold text-white">{avgConfidence}%</span>
              </div>
              <div className="flex justify-between items-center py-3 border-y border-slate-800">
                <span className="flex items-center gap-2 text-slate-400"><UserCheck className="w-4 h-4"/> Eye Contact</span>
                <span className="font-bold text-white">{avgEyeContact}%</span>
              </div>
            </div>
          </div>

          <div className="bg-slate-900/50 backdrop-blur-xl border border-slate-800 p-8 rounded-3xl">
            <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-6">Trait Analysis</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart cx="50%" cy="50%" outerRadius="80%" data={radarData}>
                  <PolarGrid stroke="#334155" opacity={0.3} />
                  <PolarAngleAxis dataKey="subject" tick={{fill: '#64748b', fontSize: 12}} />
                  <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
                  <Radar name="Candidate" dataKey="A" stroke="#6366f1" fill="#6366f1" fillOpacity={0.4} />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Right Column: Detailed Q&A Breakdown */}
        <div className="lg:col-span-2 space-y-6">
          <h2 className="text-xl font-bold text-white mb-2">Question Breakdown</h2>
          <p className="text-slate-400 mb-8 text-sm">Detailed NLP analysis of candidate responses powered by Gemini 3.5 Flash.</p>
          
          {data.details?.map((item: any, i: number) => (
            <div key={i} className="bg-slate-900/50 backdrop-blur-xl border border-slate-800 rounded-3xl p-6 lg:p-8">
              <div className="flex justify-between items-start gap-4 mb-6">
                <div>
                  <div className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest mb-2">QUESTION {i + 1}</div>
                  <h3 className="text-lg font-medium text-white">{item.question || "No question recorded"}</h3>
                </div>
                <div className="flex flex-col items-center justify-center bg-slate-800 w-16 h-16 rounded-2xl shrink-0">
                  <span className="text-xl font-light text-indigo-400">{item.score || "-"}</span>
                </div>
              </div>

              <div className="mb-6">
                <div className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">Candidate Transcript</div>
                <div className="bg-slate-950/50 border border-slate-800 p-4 rounded-2xl text-slate-400 italic text-sm">
                  "{item.transcript}"
                </div>
              </div>

              <div>
                <div className="flex items-center gap-2 text-[10px] font-bold text-indigo-400 uppercase tracking-widest mb-2">
                  <Brain className="w-4 h-4"/> AI FEEDBACK
                </div>
                <p className="text-slate-300 leading-relaxed mb-4 text-sm">{item.feedback}</p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                  <div>
                    <h4 className="text-[10px] font-bold text-emerald-500 uppercase tracking-widest mb-2">Strengths</h4>
                    <ul className="space-y-1">
                      {item.strengths?.map((s:string, idx:number) => (
                        <li key={idx} className="flex items-start gap-2 text-xs text-slate-400">
                          <span className="text-emerald-500 mt-0.5">•</span> {s}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <h4 className="text-[10px] font-bold text-amber-500 uppercase tracking-widest mb-2">Areas for Improvement</h4>
                    <ul className="space-y-1">
                      {item.weaknesses?.map((w:string, idx:number) => (
                        <li key={idx} className="flex items-start gap-2 text-xs text-slate-400">
                          <span className="text-amber-500 mt-0.5">•</span> {w}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

            </div>
          ))}

          {(!data.details || data.details.length === 0) && (
             <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-8 text-center text-slate-500">
               No detailed question data available for this legacy mock interview.
             </div>
          )}

        </div>
      </div>
    </div>
  );
}
