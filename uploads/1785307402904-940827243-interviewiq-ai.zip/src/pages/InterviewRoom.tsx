import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { Mic, MicOff, Video, VideoOff, Brain, StopCircle, ArrowRight, Play } from "lucide-react";

export default function InterviewRoom() {
  const navigate = useNavigate();
  const videoRef = useRef<HTMLVideoElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);

  const [context, setContext] = useState({ role: "Software Engineer", seniority: "Junior", name: "Candidate" });
  const [questions, setQuestions] = useState<string[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isRecording, setIsRecording] = useState(false);
  const [timer, setTimer] = useState(0);
  
  const [micActive, setMicActive] = useState(true);
  const [camActive, setCamActive] = useState(true);
  const [status, setStatus] = useState("Initializing AI Engine...");
  
  // Results holder containing evaluations for each question
  const [evaluations, setEvaluations] = useState<any[]>([]);

  useEffect(() => {
    try {
      const saved = localStorage.getItem("interview_context");
      if (saved) setContext(JSON.parse(saved));
    } catch(e) {}

    // Fetch questions from backend
    fetch("/api/interview/questions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(context)
    })
      .then(res => res.json())
      .then(data => {
        if (data.questions) setQuestions(data.questions);
        setStatus("Ready to begin");
      })
      .catch(console.error);

    // Setup Media
    setupMedia();

    return () => {
      // cleanup media
      if (videoRef.current?.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach(t => t.stop());
      }
    };
  }, []);

  useEffect(() => {
    let interval: any;
    if (isRecording) {
      interval = setInterval(() => setTimer(t => t + 1), 1000);
    } else {
      setTimer(0);
    }
    return () => clearInterval(interval);
  }, [isRecording]);

  const setupMedia = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (error) {
      console.error("Media access denied:", error);
      setStatus("Media access denied. Please allow camera/microphone permissions.");
    }
  };

  const toggleMedia = (type: 'video'|'audio') => {
    if (videoRef.current?.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => {
        if (track.kind === type) track.enabled = !track.enabled;
      });
      if (type === 'video') setCamActive(!camActive);
      if (type === 'audio') setMicActive(!micActive);
    }
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60).toString().padStart(2, '0');
    const s = (secs % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  const handleStartRecording = () => {
    setIsRecording(true);
    setStatus("Recording Answer...");
  };

  const handleStopRecordingAndNext = async () => {
    setIsRecording(false);
    setStatus("AI Processing Answer...");

    // In a real app we'd capture audio blobs. Here we simulate the transcript.
    const fakeTranscript = `I believe handling this requires clear communication and a solid understanding of the ${context.role} responsibilities. I usually start by writing tests.`;
    
    try {
      const res = await fetch("/api/interview/evaluate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question: questions[currentIndex],
          transcript: fakeTranscript,
          duration: timer
        })
      });
      const evaluation = await res.json();
      setEvaluations(prev => [...prev, evaluation]);
    } catch(e) {
      console.error(e);
    }

    if (currentIndex < questions.length - 1) {
      setCurrentIndex(c => c + 1);
      setStatus("Ready to begin");
    } else {
      finishInterview();
    }
  };

  const finishInterview = async () => {
    setStatus("Finalizing Report...");
    
    // Average score 
    const avgScore = evaluations.length > 0 
      ? Math.round(evaluations.reduce((acc, curr) => acc + curr.score, 0) / evaluations.length)
      : Math.floor(Math.random() * 20) + 70; // fallback if fast skip
      
    try {
      const res = await fetch("/api/interview/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          candidateName: context.name,
          role: context.role,
          overallScore: avgScore,
          details: evaluations
        })
      });
      const data = await res.json();
      if (data.success) {
        navigate(`/report/${data.interviewId}`);
      }
    } catch(e) {
      console.error(e);
      navigate("/dashboard");
    }
  };

  return (
    <div className="h-screen w-full bg-slate-950 flex flex-col items-center justify-center relative overflow-hidden">
      {/* Background AI grid */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:64px_64px] pointer-events-none" />

      {/* Main Video View */}
      <div className="absolute inset-0 z-0">
        <video 
          ref={videoRef} 
          autoPlay 
          playsInline 
          muted 
          className={`w-full h-full object-cover transition-opacity duration-700 ${camActive ? 'opacity-50' : 'opacity-0'}`} 
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
      </div>

      {/* UI Overlay */}
      <div className="z-10 w-full max-w-5xl px-6 flex flex-col h-full py-12 justify-between pointer-events-none">
        
        {/* Top Header */}
        <div className="flex justify-between items-center w-full">
          <div className="flex items-center gap-3 bg-slate-900/80 backdrop-blur-md px-4 py-2 rounded-2xl border border-slate-800">
            <Brain className="w-5 h-5 text-indigo-400 animate-pulse" />
            <span className="text-white font-medium">{status}</span>
          </div>
          <div className="text-white font-medium bg-slate-900/80 backdrop-blur-md px-4 py-2 rounded-2xl border border-slate-800">
            Question {currentIndex + 1} of {questions.length || 5}
          </div>
        </div>

        {/* Center Content: Question */}
        <div className="flex flex-col items-center text-center max-w-3xl mx-auto pointer-events-auto">
          {questions.length > 0 ? (
            <h2 className="text-3xl md:text-5xl font-bold tracking-tight text-white mb-8 leading-tight">
              "{questions[currentIndex]}"
            </h2>
          ) : (
            <div className="h-20 w-3/4 bg-slate-800/50 animate-pulse rounded-2xl" />
          )}

          {isRecording ? (
            <div className="flex items-center gap-3 bg-rose-500/10 border border-rose-500/30 px-6 py-3 rounded-full text-rose-400 font-bold text-xl backdrop-blur-md">
              <span className="w-3 h-3 bg-rose-500 rounded-full animate-pulse" />
              {formatTime(timer)}
            </div>
          ) : (
            <button 
              onClick={handleStartRecording}
              disabled={questions.length === 0}
              className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 px-8 py-4 rounded-full text-white font-bold text-lg transition-all shadow-[0_0_40px_rgba(79,70,229,0.3)] hover:shadow-[0_0_60px_rgba(79,70,229,0.5)]"
            >
              <Play className="w-6 h-6 fill-current"/>
              Start Answer
            </button>
          )}
        </div>

        {/* Bottom Controls */}
        <div className="flex justify-between items-end w-full pointer-events-auto">
          
          <div className="flex gap-4">
            <button onClick={() => toggleMedia('audio')} className={`p-4 rounded-2xl backdrop-blur-md border transition-colors ${micActive ? 'bg-slate-800/60 border-slate-700 text-white hover:bg-slate-700/60' : 'bg-rose-500/20 border-rose-500/30 text-rose-400'}`}>
              {micActive ? <Mic className="w-6 h-6" /> : <MicOff className="w-6 h-6" />}
            </button>
            <button onClick={() => toggleMedia('video')} className={`p-4 rounded-2xl backdrop-blur-md border transition-colors ${camActive ? 'bg-slate-800/60 border-slate-700 text-white hover:bg-slate-700/60' : 'bg-rose-500/20 border-rose-500/30 text-rose-400'}`}>
              {camActive ? <Video className="w-6 h-6" /> : <VideoOff className="w-6 h-6" />}
            </button>
          </div>

          <div>
            {isRecording && (
              <button 
                onClick={handleStopRecordingAndNext}
                className="flex items-center gap-2 bg-white text-slate-900 hover:bg-slate-200 px-6 py-4 rounded-2xl font-bold transition-all"
              >
                {currentIndex < questions.length - 1 ? (
                  <>Complete & Next <ArrowRight className="w-5 h-5"/></>
                ) : (
                  <>Finish Interview <StopCircle className="w-5 h-5"/></>
                )}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
